//
//  NearbyCell.swift
//  Coffee_App
//
//  Created by 강다해 on 20/5/2022.
//

import Foundation
import UIKit
import MapKit

class NearbyCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()

    }

    func updateUI(responseResult: MKMapItem) {
       // cellTitle
    }

}
